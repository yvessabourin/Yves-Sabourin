System.register(["angular2/testing", "angular2/http", "angular2/http/testing", "angular2/core", './yoda.service', "rxjs/Observable", 'rxjs/add/operator/map', './app', 'angular2/testing', 'angular2/platform/testing/browser'], function(exports_1) {
    var testing_1, http_1, testing_2, core_1, yoda_service_1, Observable_1, app_1, testing_3, browser_1;
    var StubYodaService;
    return {
        setters:[
            function (testing_1_1) {
                testing_1 = testing_1_1;
            },
            function (http_1_1) {
                http_1 = http_1_1;
            },
            function (testing_2_1) {
                testing_2 = testing_2_1;
            },
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (yoda_service_1_1) {
                yoda_service_1 = yoda_service_1_1;
            },
            function (Observable_1_1) {
                Observable_1 = Observable_1_1;
            },
            function (_1) {},
            function (app_1_1) {
                app_1 = app_1_1;
            },
            function (testing_3_1) {
                testing_3 = testing_3_1;
            },
            function (browser_1_1) {
                browser_1 = browser_1_1;
            }],
        execute: function() {
            StubYodaService = (function () {
                function StubYodaService() {
                }
                StubYodaService.prototype.yodaSpeak = function (sentenceString) {
                    var data = { "_body": "Yoda, I am yoda.", "status": 200, "ok": true, "statusText": "Ok", "headers": { "Date": ["Thu", " 05 May 2016 18:34:12 GMT"], "Via": ["1.1 vegur"], "Server": ["Mashape/5.0.6"], "X-Powered-By": ["Express"], "Content-Type": ["text/html; charset=utf-8"], "access-control-allow-origin": ["https://run.plnkr.co"], "access-control-allow-credentials": ["true"], "Connection": ["keep-alive"], "Content-Length": ["18"] }, "type": 2, "url": "https://yoda.p.mashape.com/yoda?sentence=I%20am%20Yoda" };
                    return Observable_1.Observable.create(function (observer) {
                        observer.next(data);
                        observer.complete();
                    });
                };
                return StubYodaService;
            })();
            testing_3.setBaseTestProviders(browser_1.TEST_BROWSER_PLATFORM_PROVIDERS, browser_1.TEST_BROWSER_APPLICATION_PROVIDERS);
            testing_1.describe("App", function () {
                testing_1.beforeEachProviders(function () {
                    return [
                        app_1.App,
                        http_1.BaseRequestOptions,
                        testing_2.MockBackend,
                        core_1.provide(yoda_service_1.YodaService, { useClass: StubYodaService }),
                        core_1.provide(http_1.Http, {
                            useFactory: function (backend, defaultOptions) {
                                return new http_1.Http(backend, defaultOptions);
                            }, deps: [testing_2.MockBackend, http_1.BaseRequestOptions]
                        }),
                    ];
                });
                testing_1.it("should create the cmp", testing_1.injectAsync([testing_1.TestComponentBuilder], function (tcb) {
                    return tcb.createAsync(app_1.App).then(function (fixture) {
                        fixture.detectChanges();
                        // Dom element created?
                        var element = fixture.debugElement.nativeElement;
                        testing_1.expect(element).toBeDefined();
                        // Angular component created?            
                        var component = fixture.debugElement.componentInstance;
                        testing_1.expect(component).toBeDefined();
                    });
                }));
                testing_1.it("should create the cmp and translate the sentence", testing_1.injectAsync([testing_1.TestComponentBuilder], function (tcb) {
                    return tcb.createAsync(app_1.App).then(function (fixture) {
                        fixture.detectChanges();
                        // Dom element created?
                        var element = fixture.debugElement.nativeElement;
                        testing_1.expect(element).toBeDefined();
                        // Angular component created?            
                        var component = fixture.debugElement.componentInstance;
                        testing_1.expect(component).toBeDefined();
                        // Check translated sentence.
                        testing_1.expect(component._sentence).toBe("Yoda, I am yoda.");
                    });
                }));
            });
        }
    }
});
