exports.config = {
    onPrepare: function() {
        var jasmineReporters = require('jasmine-reporters');
        jasmine.getEnv().addReporter(new jasmineReporters.JUnitXmlReporter({
            consolidateAll: true,
            savePath: 'test/e2ereport',
            filePrefix: 'e2ereport'
        }));
    },

    // A callback function called once tests are finished.
    onComplete: function() {
        var path = require("path");
        var reportPath = path.join(__dirname, '.', '/test/e2ereport');

        var HTMLReport = require('jasmine-xml2html-converter');

        // Call custom report for html output
        testConfig = {
            reportTitle: 'PACMAN E2E Report',
            outputPath: reportPath
        };
        new HTMLReport().from(reportPath + '/e2ereport.xml', testConfig);
    },
    allScriptsTimeout: 11000,
    framework: 'jasmine2',
    specs: ['test/saveRequestHeader.js', 'test/deleteRequest.js', 'test/approveRequest.js', 'test/approveRequestError.js', 'test/skipRebaRequest.js'],
    jasmineNodeOpts: {
        defaultTimeoutInterval: 30000
    },
    useAllAngular2AppRoots: true
}