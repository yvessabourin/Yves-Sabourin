const gulp = require('gulp');
const print = require('gulp-print');
const del = require('del');
const typescript = require('gulp-typescript');
const tscConfig = require('./src/tsconfig.json');
const sourcemaps = require('gulp-sourcemaps');
const browserSync = require('browser-sync');
const reload = browserSync.reload;
const Server = require('karma').Server;
const gulpSequence = require('gulp-sequence');
const tslint = require('gulp-tslint');

/*
 * Commands to execute:
 * Build and watch:           gulp watch
 * Build and run unit tests:  gulp test
 * Build:                     gulp build
 */

gulp.task('print', function() {
  return gulp
    .src([
        'node_modules/angular2/typings/browser.d.ts',
        'src/**/*.ts'
    ])
    .pipe(print())
});

// Pre-build clean
gulp.task('prebuild:clean', function() {
    return del(['WebContent/**/*.js', 'WebContent/**/*.map', 'WebContent/**/*.html', '!WebContent/login_error.html', '!WebContent/login.html', '!WebContent/mmpcPacMan.html', '!WebContent/noaccess.html', '!WebContent/*.jsp', '!WebContent/WEB-INF/**/*']);
});

// Post-build clean
gulp.task('postbuild:clean', function() {
    return del(['WebContent/**/*.spec.js']).then(paths => {
        console.log("Ignoring " + paths.length + " spec files.");
    });
});

// Lint and Compile ts
gulp.task('compile', ['prebuild:clean'], function() {
    return gulp
        .src([
            'node_modules/angular2/typings/browser.d.ts',
            'typings/jasmine/jasmine.d.ts',
            'src/**/*.ts'
        ])
        .pipe(typescript(tscConfig.compilerOptions))
        .pipe(gulp.dest('WebContent'));
});

gulp.task('copy:assets', ['compile'], function() {
// Copy static assets(html,img,css,etc)
    return gulp.src(['src/**/*', '!src/**/*.ts'])
        .pipe(gulp.dest('WebContent'))
});

// Copy js libs
gulp.task('copy:js', ['compile'], function() {
    return gulp.src([
            './node_modules/es6-shim/es6-shim.min.js',
            './node_modules/systemjs/dist/system-polyfills.js',
            './node_modules/angular2/bundles/angular2-polyfills.min.js',
            './node_modules/systemjs/dist/system.js',
            './node_modules/rxjs/bundles/Rx.min.js',
            './node_modules/angular2/bundles/angular2.dev.js',
            './node_modules/angular2/bundles/http.min.js',
            './node_modules/angular2/bundles/router.min.js',
            './node_modules/moment/moment.js',
        ])
        .pipe(gulp.dest('WebContent/lib/js'))
});

// Copy css libs
gulp.task('copy:css', ['compile'], function() {
    return gulp.src([
            'node_modules/bootstrap/dist/css/bootstrap.min.css',
            'node_modules/font-awesome/css/font-awesome.min.css',
        ])
        .pipe(gulp.dest('WebContent/lib/css'))
});

// Copy font libs
gulp.task('copy:fonts', ['compile'], function() {
    return gulp.src([
            'node_modules/font-awesome/fonts/*',
        ])
        .pipe(gulp.dest('WebContent/lib/fonts'))
});

// Watch src and rebuild
gulp.task('watch', ['srcbuild'], function() {
    browserSync({
        server: {
            baseDir: 'WebContent'
        }
    });

    gulp.watch(['src/**/*', 'index.html', 'styles.css'], ['serve']);
});

// Run unit tests, but run build first
gulp.task('test', ['srcbuild'], function(done) {
    new Server({
        configFile: __dirname + '/karma.conf.js',
        singleRun: true
    }, done).start();
});

gulp.task('srcbuild', ['compile', 'copy:js', 'copy:css', 'copy:fonts', 'copy:assets']);
gulp.task('build', gulpSequence('srcbuild', 'postbuild:clean'))
gulp.task('serve', ['srcbuild'], reload);
gulp.task('default', ['watch']);