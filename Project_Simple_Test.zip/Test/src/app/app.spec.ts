import {it, describe, expect, inject, fakeAsync, afterEach,
  beforeEachProviders, tick, TestComponentBuilder, injectAsync} from "angular2/testing";
import {Http, ConnectionBackend, BaseRequestOptions, Response, ResponseOptions, RequestMethod} from "angular2/http";
import {MockBackend} from "angular2/http/testing";
import {provide} from "angular2/core";
import {YodaService} from './yoda.service';
import {Observable} from "rxjs/Observable";
import 'rxjs/add/operator/map';
import {App} from './app';
import {setBaseTestProviders} from 'angular2/testing';

import {
  TEST_BROWSER_PLATFORM_PROVIDERS,
  TEST_BROWSER_APPLICATION_PROVIDERS
} from 'angular2/platform/testing/browser';

class StubYodaService {
  public yodaSpeak(sentenceString: string) {
    var data: any = { "_body": "Yoda, I am yoda.", "status": 200, "ok": true, "statusText": "Ok", "headers": { "Date": ["Thu", " 05 May 2016 18:34:12 GMT"], "Via": ["1.1 vegur"], "Server": ["Mashape/5.0.6"], "X-Powered-By": ["Express"], "Content-Type": ["text/html; charset=utf-8"], "access-control-allow-origin": ["https://run.plnkr.co"], "access-control-allow-credentials": ["true"], "Connection": ["keep-alive"], "Content-Length": ["18"] }, "type": 2, "url": "https://yoda.p.mashape.com/yoda?sentence=I%20am%20Yoda" };
    return Observable.create(observer => {
      observer.next(data);
      observer.complete();
    });
  }
}

setBaseTestProviders(TEST_BROWSER_PLATFORM_PROVIDERS, TEST_BROWSER_APPLICATION_PROVIDERS);

describe("App", () => {
  beforeEachProviders(() => {
    return [
      App,
      BaseRequestOptions,
      MockBackend,
      provide(YodaService, { useClass: StubYodaService }),
      provide(Http, {
        useFactory: (backend: ConnectionBackend, defaultOptions: BaseRequestOptions) => {
          return new Http(backend, defaultOptions);
        }, deps: [MockBackend, BaseRequestOptions]
      }),
    ];
  });

  it("should create the cmp", injectAsync([TestComponentBuilder], (tcb: TestComponentBuilder) => {
    return tcb.createAsync(App).then((fixture) => {
      fixture.detectChanges();

      // Dom element created?
      let element: any = fixture.debugElement.nativeElement;
      expect(element).toBeDefined();

      // Angular component created?            
      let component: App = fixture.debugElement.componentInstance;
      expect(component).toBeDefined();
    });
  }));

  it("should create the cmp and translate the sentence", injectAsync([TestComponentBuilder], (tcb: TestComponentBuilder) => {
    return tcb.createAsync(App).then((fixture) => {
      fixture.detectChanges();

      // Dom element created?
      let element: any = fixture.debugElement.nativeElement;
      expect(element).toBeDefined();

      // Angular component created?            
      let component: App = fixture.debugElement.componentInstance;
      expect(component).toBeDefined();

      // Check translated sentence.
      expect(component._sentence).toBe("Yoda, I am yoda.");
    });
  }));

});