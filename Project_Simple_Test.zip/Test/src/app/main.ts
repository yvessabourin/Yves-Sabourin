//main entry point
import {bootstrap} from 'angular2/platform/browser';
import {App} from './app';
import {Http} from 'angular2/http';
import {HTTP_PROVIDERS} from 'angular2/http';
import {YodaService} from './yoda.service';
import "rxjs/Rx";

bootstrap(App, [YodaService, HTTP_PROVIDERS ])
  .catch(err => console.error(err));