import {Http, URLSearchParams, Headers} from 'angular2/http';
import {HTTP_PROVIDERS} from 'angular2/http';
import {Injectable} from 'angular2/core';

@Injectable()
export class YodaService {
  
  constructor(private http:Http) {
    console.log('YodaSvc:' + http);
  }
  
  public yodaSpeak(sentenceString:string){

    let params: URLSearchParams = new URLSearchParams();
    params.set('sentence', sentenceString);

    let headers:Headers = new Headers();
    headers.append('X-Mashape-Key', 'OxWYjpdztcmsheZU9AWLNQcE9g9wp1qdRkFjsneaEp2Yf68nYH');
    headers.append('Accept', 'text/plain');
    
    return this.http.get(
      "https://yoda.p.mashape.com/yoda", 
      { search:params,
      headers: headers });
  }
}