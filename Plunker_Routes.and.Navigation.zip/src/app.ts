//our root app component
import {View, Component} from 'angular2/core'
import {RouteConfig, Router, RouterLink, RouterOutlet, ROUTER_DIRECTIVES} from 'angular2/router';

@Component({
  selector: 'home',
  providers: [],
  template: `
    <div>
      <h2>Home</h2>
    </div>
  `,
  directives: []
})
export class Home {
  constructor() {
  }
}

@Component({
  selector: 'other',
  providers: [],
  template: `
    <div>
      <h2>other</h2>
    </div>
  `,
  directives: []
})
export class Other {
  constructor() {
  }
}

@Component({
  selector: 'my-app',
  template: `
    <header style="border-bottom:1px solid black">
      <a [routerLink]="['./Home']">Home</a>
      &nbsp;
      <a [routerLink]="['./Other']">Other</a>
    </header>
    <main>
    <router-outlet></router-outlet>
    </main>
  `,
  directives: [RouterLink, RouterOutlet]
})
@RouteConfig([
  { path: '/', component: Home, as: 'Home', useAsDefault: true },
  { path: '/other', component: Other, as: 'Other' }
])
export class App {
  constructor(router:Router) {
  }
}