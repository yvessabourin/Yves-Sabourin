# PacMan_UI2

## Prerequisites
- node.js
- git
- protractor


## Quick Start
```sh
# Clone
git clone https://github.homedepot.com/Pricing/PacMan_UI2

# Go into directory
cd PacMan_UI2

# Install dependencies using npm
npm install

# Start the server
npm start
```

## Other commands
```sh
# Build
npm run build

# Run unit tests
npm run test

# Run e2e tests
npm run webdriver:update // run once
npm run e2e // run on separate terminal
```

## Contributing
See [Contribution Guidelines](https://github.homedepot.com/Pricing/PacMan_UI2/wiki/Contributing)
