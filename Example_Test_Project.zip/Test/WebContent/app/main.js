System.register(['angular2/platform/browser', './app', 'angular2/http', './yoda.service', "rxjs/Rx"], function(exports_1) {
    var browser_1, app_1, http_1, yoda_service_1;
    return {
        setters:[
            function (browser_1_1) {
                browser_1 = browser_1_1;
            },
            function (app_1_1) {
                app_1 = app_1_1;
            },
            function (http_1_1) {
                http_1 = http_1_1;
            },
            function (yoda_service_1_1) {
                yoda_service_1 = yoda_service_1_1;
            },
            function (_1) {}],
        execute: function() {
            browser_1.bootstrap(app_1.App, [yoda_service_1.YodaService, http_1.HTTP_PROVIDERS])
                .catch(function (err) { return console.error(err); });
        }
    }
});
