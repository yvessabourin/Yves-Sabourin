System.register(["angular2/testing", "angular2/http", "angular2/http/testing", "angular2/core", './yoda.service', 'rxjs/add/operator/map'], function(exports_1) {
    var testing_1, http_1, testing_2, core_1, yoda_service_1;
    return {
        setters:[
            function (testing_1_1) {
                testing_1 = testing_1_1;
            },
            function (http_1_1) {
                http_1 = http_1_1;
            },
            function (testing_2_1) {
                testing_2 = testing_2_1;
            },
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (yoda_service_1_1) {
                yoda_service_1 = yoda_service_1_1;
            },
            function (_1) {}],
        execute: function() {
            testing_1.describe("YodaSvc", function () {
                testing_1.beforeEachProviders(function () {
                    return [
                        http_1.BaseRequestOptions,
                        testing_2.MockBackend,
                        yoda_service_1.YodaService,
                        core_1.provide(http_1.Http, {
                            useFactory: function (backend, defaultOptions) {
                                return new http_1.Http(backend, defaultOptions);
                            }, deps: [testing_2.MockBackend, http_1.BaseRequestOptions]
                        }),
                    ];
                });
                testing_1.it("should return the word Yoda", testing_1.inject([yoda_service_1.YodaService, testing_2.MockBackend], testing_1.fakeAsync(function (svc, backend) {
                    setResponse(backend, "Yoda, I am yoda.  Hmmmmmm.");
                    var res;
                    svc.yodaSpeak("Who are you?")
                        .map(function (res) { return res; })
                        .subscribe(function (_res) {
                        res = _res;
                    });
                    testing_1.tick();
                    // Does it contain the word 'Yoda'?
                    var yodaIdx = res._body.toLowerCase().indexOf('yoda');
                    testing_1.expect(yodaIdx).toBeGreaterThan(-1);
                })));
                function setResponse(backend, res) {
                    backend.connections.subscribe(function (c) {
                        var response = new http_1.ResponseOptions({ body: JSON.stringify(res) });
                        c.mockRespond(new http_1.Response(response));
                    });
                }
            });
        }
    }
});
