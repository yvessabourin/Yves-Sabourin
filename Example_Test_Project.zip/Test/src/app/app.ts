//our root app component
import {Component} from 'angular2/core';
import {YodaService} from './yoda.service';
import {Http, Headers, Response} from "angular2/http";
import {Observable} from "rxjs/Observable";


@Component({
  selector: 'my-app',
  providers: [ ],
  template: `
    <div>
      <h2>Translation: {{_sentence}}</h2>
    </div>
  `,
  directives: []
})
export class App {
  public _sentence: string = "";
  
  constructor(private yodaSvc:YodaService) {
    
    // Translate a sentence.
    this.translateSentence("I am Yoda")
      .map((res:any) => res)
      .subscribe(
          data => {
            console.log(JSON.stringify(data));
            this._sentence = data._body;
          },
        error => console.log("Error - " + error)
        );
  }
  
  public translateSentence(sentence:string) {
    return this.yodaSvc.yodaSpeak(sentence);
  }
  
}