import {it, describe, expect, inject, fakeAsync,
  beforeEachProviders, tick} from "angular2/testing";
import {Http, ConnectionBackend, BaseRequestOptions, Response, ResponseOptions} from "angular2/http";
import {MockBackend} from "angular2/http/testing";
import {provide} from "angular2/core";
import {YodaService} from './yoda.service';
import {Observable} from "rxjs/Observable";
import 'rxjs/add/operator/map';

describe("YodaSvc", () => {
  beforeEachProviders(() => {
    return [
      BaseRequestOptions,
      MockBackend,
      YodaService,
      provide(Http, {
        useFactory: (backend: ConnectionBackend, defaultOptions: BaseRequestOptions) => {
          return new Http(backend, defaultOptions);
        }, deps: [MockBackend, BaseRequestOptions]
      }),
    ];
  });
  
  it ("should return the word Yoda",
      inject([YodaService, MockBackend], fakeAsync((svc: YodaService, backend) => {
        
          setResponse(backend, "Yoda, I am yoda.  Hmmmmmm.");
          
          let res;
          svc.yodaSpeak("Who are you?")
            .map((res:any) => res)
            .subscribe((_res) => {
              res = _res;
          });
          
          tick();
          
          // Does it contain the word 'Yoda'?
          var yodaIdx = res._body.toLowerCase().indexOf('yoda');
          expect(yodaIdx).toBeGreaterThan(-1);
      }))
  );
  
  function setResponse(backend: MockBackend, res) {
      backend.connections.subscribe(c => {
      let response = new ResponseOptions({body: JSON.stringify(res)});
      c.mockRespond(new Response(response));
      });
  }
  
});