//main entry point
import {bootstrap} from 'angular2/platform/browser';
import {App} from './app';
import {Service} from './service';

bootstrap(App, [Service])
  .catch(err => console.error(err));