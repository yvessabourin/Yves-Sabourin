export class Service {
  constructor() {
    alert('Constructing Service');
  }
  isSuperCharged(car: string):string{
    if (car == "Ford GT"){
      return "yes";
    }else{
      return "no";
    }
  }
}