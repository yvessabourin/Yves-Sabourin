//our root app component
import {Component} from 'angular2/core'
import {Car} from './car';

@Component({
  selector: 'my-app',
  providers: [],
  template: `
    <div>
      <car name="Ford GT"></car>
      <car name="Corvette Z06"></car>
    </div>
  `,
  directives: [Car]
})

export class App {
  constructor() {
  }
}