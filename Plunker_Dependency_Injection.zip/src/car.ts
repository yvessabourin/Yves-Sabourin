import {Component, Input} from 'angular2/core'
import {Service} from './service';

@Component({
  selector: 'car',
  template: `
    <div>{{name}} Supercharged: {{supercharged}}</div>
  `
})
export class Car {
  @Input() name: string

  constructor(service:Service) {
    this.service = service;
  }
  
  ngOnInit(){
    this.supercharged = this.service.isSuperCharged(this.name);
  }
}