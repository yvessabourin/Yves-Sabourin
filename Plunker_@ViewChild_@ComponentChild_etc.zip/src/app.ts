//our root app component
import { Component, ViewChild, ViewChildren, ContentChildren, AfterViewInit, Input } from '@angular/core'
import { NgClass } from '@angular/common'

@Component({
  selector: 'paragraph',
  providers: [],
  template: `<p [ngClass]="{ 'bold' : bold == 'true', 'normal' : bold != 'true'}"><ng-content></ng-content></p>`,
  directives: [NgClass],
  styles: ['.bold {font-weight:bold}', '.normal {font-weight:normal}']
})
export class Paragraph {
  @Input() bold;
}

@Component({
  selector: 'header',
  providers: [],
  template: `
    <div>Welcome to {{name}}</div>
    <hr>
  `,
  directives: []
})
export class Header {
  constructor() {
    this.name = 'News of the World'
  }
}

@Component({
  selector: 'content',
  providers: [],
  template: `
    <div><ng-content></ng-content></div>
  `,
  directives: [Paragraph]
})
export class Content {
  @ContentChildren(Paragraph) paragraphList:QueryList<Paragraph>;
  ngAfterContentInit(){
    console.log("content has " + this.paragraphList.length + " paragraphs");
  }
}

@Component({
  selector: 'my-app',
  providers: [],
  template: `
    <header #header></header>
    <content>
      <paragraph bold="true">Lorem ipsum dolor sit amet.</paragraph>
      <paragraph>Alii error ne sed, sea ea vide accumsan.</paragraph>
    </content>
    <content><paragraph>Fin</paragraph></content>
  `,
  directives: [Header, Content, Paragraph]
})
export class App {
  @ViewChild('header') header:Header;
  @ViewChildren(Content) contentList:QueryList<Content>;

  ngAfterViewInit(){
    console.log("app - view init");
    console.log("header name:" + this.header.name);
    console.log("page has " + this.contentList.length + " blocks of content");
  }

}