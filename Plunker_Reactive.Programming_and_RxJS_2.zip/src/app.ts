import {Component} from 'angular2/core';
import {Control} from 'angular2/common';
import Rx, {Observable, Observer, Subscription} from 'rx.all'
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';

@Component({
  selector: 'my-app',
  template: `
      <input type="text" [ngFormControl]="term"/>
      <ul>
        <li *ngFor="#item of items">{{item}}</li>
      </ul>
  `
})
export class App {
  term = new Control();
  items = new Array();
  constructor() {

    var observer:Rx.Observer = Rx.Observer.create(
        x =>  this.handleKeystroke(x),
        e => console.log(`onError: ${e}`),
        () => console.log('onCompleted')
      );

    this.term.valueChanges
                 .debounceTime(1000)
                 .distinctUntilChanged()
                 .subscribe(observer);

                  
  }
  
  handleKeystroke(x:string):void{
    this.items = [];
    for (var index: number = 0; index < x.length; index++) {
      this.items.push(x.charAt(index));
    }
  }
  
}