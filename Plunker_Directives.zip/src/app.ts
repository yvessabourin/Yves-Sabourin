//our root app component
import {Component} from 'angular2/core'
import {Sizer} from './hoverer'

@Component({
  selector: 'my-app',
  providers: [],
  template: `
    <div>
      <p [hoverer]="#ff0000">Hello {{name}}</p>
    </div>
  `,
  directives: [Hoverer]
})
export class App {
  constructor() {
    this.name = 'Angular2'
  }
}


