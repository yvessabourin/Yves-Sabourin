import {Directive, Component, ElementRef, Renderer, Input} from 'angular2/core';

@Directive({
  selector: '[hoverer]',
  host: {
    '(mouseenter)': 'onMouseEnter()',
    '(mouseleave)': 'onMouseLeave()'
  }
})
export class Hoverer {
  
  @Input('hoverer') color: string;
  element: ElementRef;
  renderer: Renderer
  
  constructor(element: ElementRef, renderer: Renderer) {
    this.element = element;
    this.renderer = renderer;
  }
  
  onMouseEnter(){
    this.renderer.setElementStyle(this.element, 'color', color);
  }
  
  onMouseLeave(){
    this.renderer.setElementStyle(this.element, 'color', "#000000");
  }
}
