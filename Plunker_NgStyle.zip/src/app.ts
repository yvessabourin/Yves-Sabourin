import {Component} from 'angular2/core'
import {NgFor,NgStyle} from 'angular2/common'

@Component({
  selector: 'my-app',
  providers: [],
  template: `
  <div *ngFor="#animal of animals">
    <div [ngStyle]="setStyles(animal)" 
    (click)="animalClicked($event)">{{animal}}</div>
  </div>
  <br/>
  <br/>
  <template 
    ngFor #animal="$implicit" 
    [ngForOf]="animals">
    <div [ngStyle]="setStyles(animal)" 
    (click)="animalClicked($event)">{{animal}}</div>
  </template>
  `,
  directives: [NgFor]
})
export class App {
  
  animals:Any = ['dog','cat','mouse','pig'];
  selectedAnimal:String = 'dog';

  animalClicked(event:Event){
    this.selectedAnimal = event.srcElement.innerHTML.trim();
  }
  
  setStyles(animal:String){
    let styles = {
      'width' : '50px',
      'border': '1px solid black',
      'margin': '10px',
      'padding': '10px',
      'color' : ((animal == this.selectedAnimal) ? "#ffffff" : "#000000"),
      'background-color' : ((animal == this.selectedAnimal) ? "#ff0000" : "#ffffff")
    }
    return styles;
  }
  
}