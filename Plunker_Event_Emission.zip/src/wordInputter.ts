import {Component,EventEmitter} from 'angular2/core'

@Component({
  selector: 'word-inputter',
  providers: [],
  template: `
      <input type="text" (input)="wordInputEvent($event)"/>
  `,
  directives: [],
  events: ['wordInput']
})

export class WordInputter {
  
  constructor() {
    this.wordInput = new EventEmitter<string>();
  }
  
  wordInputEvent(event:string):void{
    var val:String=event.target.value;
    var wordBackwards:String = '';
    for (var i=val.length-1;i>=0;i--){
      wordBackwards += val.substring(i,i+1);
    }
    this.wordInput.emit(wordBackwards);
  }
}