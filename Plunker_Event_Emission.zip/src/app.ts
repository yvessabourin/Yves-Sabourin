import {Component, Event} from 'angular2/core'
import {WordInputter} from './wordInputter';

@Component({
  selector: 'my-app',
  providers: [],
  template: `
    <div>
      <word-inputter (wordInput)="wordInputEvent($event)"></word-inputter>
      <h2>Backwards is {{wordBackwards}}.</h2>
    </div>
  `,
  directives: [WordInputter]
})
export class App {
  constructor() {
    this.wordBackwards = '';
  }
  wordInputEvent(wordBackwards:Any):void{
    console.log("wordInputEvent" + wordBackwards);
    this.wordBackwards = wordBackwards;
  }
}