//our root app component
import {Component} from 'angular2/core'
import Rx, {Observable, Observer, Subscription} from 'rx.all'

@Component({
  selector: 'my-app',
  providers: [],
  template: `
    <div>
      <h2>Hello {{name}}</h2>
      
    </div>
  `,
  directives: []
})
export class App {
  constructor() {
    this.name = 'Angular2'
    
    var array:Array = ['event1', 'event2'];
    var observable:Rx.Observable = new Rx.Observable.of(array);
    
    var observer:Rx.Observer = Rx.Observer.create(
      x => console.log(`onNext: ${x}`),
      e => console.log(`onError: ${e}`),
      () => console.log('onCompleted')
    );

    var subscription:Rx.Subscription = observable.subscribe(observer);
    
    array.push('event3');

}