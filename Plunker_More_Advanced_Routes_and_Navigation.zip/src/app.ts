//our root app component
import {View, Component} from 'angular2/core'
import {RouteConfig, Router, RouterLink, RouterOutlet, RouteParams} from 'angular2/router';

@Component({
  selector: 'child1',
  providers: [],
  template: `
    <div>
      <h2>Child1</h2>
      <p>A subcomponent</p>
    </div>
  `,
  directives: []
})
export class Child1 {
  constructor() {
  }
}

@Component({
  selector: 'child2',
  providers: [],
  template: `
    <div>
      <h2>Child2</h2>
      <p>Another subcomponent</p>
    </div>
  `,
  directives: []
})
export class Child2 {
  constructor() {
  }
}

@Component({
  selector: 'home',
  providers: [],
  template: `
    <div>
      <h2>Home</h2>
      <p>The quick brown fox jumped over the lazy dogs.</p>
    </div>
  `,
  directives: []
})
export class Home {
  constructor() {
  }
}

@Component({
  selector: 'other',
  providers: [],
  template: `
    <div>
      <h2>Other</h2>
      <p>Id parameter: {{id}}</p>
      <a [routerLink]="['Child1']">Child1</a>
      &nbsp;
      <a [routerLink]="['Child2']">Child2</a>
      <router-outlet></router-outlet>
    </div>
  `,
  directives: [RouterLink, RouterOutlet]
})
@RouteConfig([
  { path: '/child1', component: Child1, as: 'Child1', useAsDefault: true },
  { path: '/child2', component: Child2, as: 'Child2' },
])
export class Other {
  constructor(params: RouteParams) {
    this.id = params.get('id');
  }
}

@Component({
  selector: 'my-app',
  template: `
    <header style="border-bottom:1px solid black">
      <a [routerLink]="['./Home']">Home</a>
      &nbsp;
      <a [routerLink]="['./Other',{id:1}]">Other1</a>
      &nbsp;
      <a [routerLink]="['./Other',{id:2}]">Other2</a>
    </header>
    <main>
    <router-outlet></router-outlet>
    </main>
  `,
  directives: [RouterLink, RouterOutlet]
})
@RouteConfig([
  { path: '/', component: Home, as: 'Home' },
  { path: '/other/...', component: Other, as: 'Other' }
])
export class App {
  constructor(router:Router) {
    router.navigate(['./Home']);
  }
}