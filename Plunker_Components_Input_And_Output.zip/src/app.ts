//our root app component
import {Component, Input, Output, Events, EventEmitter} from 'angular2/core'
import {NgFor} from 'angular2/common'

export interface ICar{
    id : number,
    make : string,
    model : string
}


@Component({
  selector: 'car',
  providers: [],
  template: `
    <div ngClass="car">
      {{car.make}} {{car.model}}
      <button (click)="delete(car)" ngClass="deleteButton">Delete</button>
    </div>
  `,
  directives: [],
  styles: [
  `
    .car {text-align:center;width:120px;border:1px solid black;margin:10px}
    .deleteButton {border:1px solid black;margin:10px}
  `
  ]
})
export class Car {
  @Input() car: ICar;
  @Output() carDelete = new EventEmitter();
  
  delete(car:ICar) {
    this.carDelete.emit(car);
  }
}


@Component({
  selector: 'my-app',
  providers: [],
  template: `
    <car *ngFor="#car of cars" [car]="car" (carDelete)="deleteCar(car)"></car>
  `,
  directives: [Car, NgFor]
})
export class App {
  cars:Array<ICar> = [
    {id:1,make:'Chevy',model:'Corvette'},
    {id:2,make:'Porsche',model:'911'},
    {id:3,make:'BMW',model:'M3'}
    ];
  deleteCar(car:ICar) {
    confirm('Delete car ' + car.make + ' ' + car.model + '?');
  }
}