import {Component} from 'angular2/core'
import {provide} from 'angular2/core';

class ConfigService {
  constructor(){
    this.serverName = 'none';
  }
  getServerName(): string{
    return this.serverName;
  }
}
class TestingConfigService extends ConfigService {
  constructor(){
    this.serverName = 'test123';
  }
}
class ProducConfigService extends ConfigService {
  constructor(){
    this.serverName = 'prod';
  }
}
@Component({
  selector: 'my-app',
  template: `<div>{{serverName}}</div>`,
  directives: [],
  providers: [provide(ConfigService, {useValue: ConfigService})]
})
export class App {
  constructor(svc:ConfigService) {
    this.serverName = svc.getServerName();
  }
}

