/*
 * Providers provided by Angular
 */
import {bootstrap} from 'angular2/platform/browser';
import {Injector} from 'angular2/core';
import {ROUTER_PROVIDERS} from 'angular2/router';
import {HTTP_PROVIDERS} from 'angular2/http';
import {FORM_PROVIDERS} from 'angular2/common';
import {ELEMENT_PROBE_PROVIDERS} from 'angular2/platform/common_dom';
import {App} from './app/components/app';
import {WeatherSvc} from './app/services/weatherSvc';

function main() {
  return bootstrap(App, [
    FORM_PROVIDERS,
    HTTP_PROVIDERS,
    ROUTER_PROVIDERS,
    ELEMENT_PROBE_PROVIDERS,
    WeatherSvc
  ])
  .catch(err => console.error(err));
}

document.addEventListener('DOMContentLoaded', main);
