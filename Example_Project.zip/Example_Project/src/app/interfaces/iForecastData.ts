import {IMainData} from './iMainData';
export interface IForecastData {
    clouds : string,
    dt_txt : string,
    main : IMainData    
}