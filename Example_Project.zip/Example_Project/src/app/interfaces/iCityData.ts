import {ICoOrdData} from './iCoOrdData';

export interface ICityData{
    coord:ICoOrdData,
    country:string,
    name:string
}