export interface IWindData{
    deg : number,
    speed : number
}