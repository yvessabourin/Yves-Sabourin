export interface ICoOrdData{
    lon : number,
    lat : number
}