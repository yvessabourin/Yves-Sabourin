export interface IWeatherData{
    description : string,
    icon : string,
    id : string,
    main :string
}