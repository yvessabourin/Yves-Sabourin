export interface ISavedLocationData{
    cityName? : string,
    countryCode? : string,
    zip? : string,
    name? : string
}