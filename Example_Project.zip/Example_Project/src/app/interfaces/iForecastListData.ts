import {IForecastData} from './iForecastData';

export interface IForecastListData extends Array<IForecastData>{
}