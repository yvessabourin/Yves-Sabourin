import {Component, Input} from 'angular2/core';
import {NgIf} from 'angular2/common';
import {ICoOrdData} from '../interfaces/iCoOrdData';

@Component({
    selector: 'map', 
    directives: [NgIf],
    template: `
    <div class="row">
        <div class="col-xs-1">&nbsp;</div>
        <img *ngIf="model" class="col-xs-10" 
            src="http://maps.google.com/maps/api/staticmap?center={{model.lat}},{{model.lon}}&zoom=8&size=400x300&sensor=false"/>
        <div class="col-xs-1">&nbsp;</div>
    </div>    
    `
})

export class Map {
    @Input() model:ICoOrdData;
}
