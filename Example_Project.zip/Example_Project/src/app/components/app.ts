import {View, Component} from 'angular2/core';
import {CORE_DIRECTIVES, FORM_DIRECTIVES, NgModel, NgIf, NgFor } from 'angular2/common';
import {Accordion, AccordionGroup} from 'ng2-bootstrap/ng2-bootstrap';
import {WeatherSvc} from '../services/weatherSvc';
import {SavedLocationsSelector} from './savedLocationsSelector';
import {SavedLocationsEditor} from './savedLocationsEditor';
import {City} from './city';
import {Current} from './current';
import {FiveDay} from './fiveDay';
import {Map} from './map';

@Component({
  selector: 'app', 
  directives: [CORE_DIRECTIVES, FORM_DIRECTIVES, SavedLocationsSelector, SavedLocationsEditor, City, Accordion, AccordionGroup, Current, FiveDay, Map],
  template: `
    <header>
        <savedlocationsselector (edit)="isEditingLocations=true" 
            *ngIf="!isEditingLocations"></savedlocationsselector>
        <savedlocationseditor (close)="isEditingLocations=false" 
            *ngIf="isEditingLocations"></savedlocationseditor>
    </header>
    <main>
        <br/>
        <city [model]="weatherSvc?.cityData"></city>
        <map [model]="weatherSvc?.coOrdData"></map>
        <br/>
        <accordion closeOthers="true">
            <accordion-group isOpen="true" heading="Current">
                <current></current>
            </accordion-group>
            <accordion-group heading="5 Day">
                <fiveday></fiveday>
            </accordion-group>
        </accordion>            
    </main>
    <footer>
    </footer>
  `
})

export class App {
    isEditingLocations:boolean = false;
    weatherSvc:WeatherSvc;
    
    constructor (weatherSvc:WeatherSvc){
        this.weatherSvc = weatherSvc;
    }
    editLocations(){
        this.isEditingLocations = true;
    }  
    stopEditingLocations(){
        this.isEditingLocations = false;        
    }
}