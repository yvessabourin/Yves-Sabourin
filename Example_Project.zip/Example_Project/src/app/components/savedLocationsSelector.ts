import {Component, Output, EventEmitter} from 'angular2/core';
import {NgIf, NgFor} from 'angular2/common';
import {ButtonRadio} from 'ng2-bootstrap/ng2-bootstrap';
import {WeatherSvc} from '../services/weatherSvc';
import {ISavedLocationData} from '../interfaces/iSavedLocationData';

@Component({
    selector: 'savedlocationsselector', 
    directives: [NgIf, NgFor],
    template: `
    <div class="row" style="background-color:#f6f6f6;border-bottom:1px solid #e2e2e2" *ngIf="(weatherSvc.getSavedLocations())">
        <div class="col-xs-1">&nbsp;</div>
        <div class="col-xs-10">
            <span *ngFor="#location of weatherSvc.getSavedLocations()">
            <label *ngIf="location.name"
                class="btn btn-primary"
                style="margin:5px;"
                btnRadio="location" 
                (click)="locationClicked(location)">{{ location?.name }}</label>
            </span>
            <label style="margin:5px;"
                class="btn btn-primary"
                (click)="editClicked()">...</label>
        </div>    
        <div class="col-xs-1">&nbsp;</div>
    </div>
    `
}) 

export class SavedLocationsSelector {
    weatherSvc:WeatherSvc;
    @Output() edit = new EventEmitter();

    constructor(weatherSvc:WeatherSvc) {
        this.weatherSvc = weatherSvc;
    }
    
    locationClicked(location:ISavedLocationData){
        this.weatherSvc.savedLocationChanged(location);
    }
    
    editClicked(){
        this.edit.emit(null);        
    }
                   
}
