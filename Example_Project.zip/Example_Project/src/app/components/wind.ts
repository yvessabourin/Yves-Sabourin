import {Component, Input} from 'angular2/core';
import {IWindData} from '../interfaces/iWindData';

@Component({
    selector: 'wind',
    template: `
    <p>
    Wind Direction: {{model?.deg}}, 
    Wind Speed: {{model?.speed}}
    </p>
    `
}) 

export class Wind {
    @Input() model:IWindData;
}
