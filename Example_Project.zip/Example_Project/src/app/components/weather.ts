import {Component, Input} from 'angular2/core';
import {NgIf} from 'angular2/common';
import {IWeatherData} from '../interfaces/iWeatherData';

@Component({
    selector: 'weather', 
    directives: [NgIf],
    styles: [`
    img {width:100px}
    `],
    template: `
    <p *ngIf="model"><img src="http://openweathermap.org/img/w/{{model?.icon}}.png"/></p>
    <p>{{model?.main}} ({{model?.description}})</p>
    `
})

export class Weather {
    @Input() model:IWeatherData;
}
