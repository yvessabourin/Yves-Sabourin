import {Component, Input} from 'angular2/core';
import {ICityData} from '../interfaces/iCityData';

@Component({
    selector: 'city',
    template: `
    <div class="row">
        <div class="col-xs-1">&nbsp;</div>
        <div class="col-xs-10">
            <b>{{model?.name}},{{model?.country}}</b>
        </div>
        <div class="col-xs-1">&nbsp;</div>
    </div>
    `
}) 

export class City {
    @Input() model:ICityData;
}
