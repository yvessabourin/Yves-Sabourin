/*
 * Angular 2 decorators and services
 */
import {Http, Response} from 'angular2/http';
import {View, Component, NgZone} from 'angular2/core';
import {RouteConfig, Router, ROUTER_DIRECTIVES} from 'angular2/router';
import {FORM_PROVIDERS, NgIf} from 'angular2/common';
import {WeatherSvc} from '../services/weatherSvc';
import {ForecastList} from './forecastList';

@Component({
    selector: 'fiveday', 
    providers: [...FORM_PROVIDERS],
    directives: [ForecastList],
    template: `
    <div>
    <forecastlist [model]="weatherSvc?.forecastListData"></forecastlist>
    </div>
  `
})

export class FiveDay {
    weatherSvc: WeatherSvc;
    
    constructor(weatherSvc: WeatherSvc) {
        this.weatherSvc = weatherSvc;
    }            
}
