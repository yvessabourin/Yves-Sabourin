import {Component, Output, EventEmitter} from 'angular2/core';
import {NgFor, NgIf} from 'angular2/common';
import {FORM_DIRECTIVES, FormBuilder, ControlGroup, Validators, Control} from 'angular2/common';
import {WeatherSvc} from '../services/weatherSvc';
import {ISavedLocationData} from '../interfaces/iSavedLocationData';

@Component({
    selector: 'savedlocationseditor', 
    directives: [NgFor, NgIf, ...FORM_DIRECTIVES],
    styles: [`
        .ng-valid[required]{
            border-right:10px solid #42a948;
        }
        .ng-invalid[required]{
            border-right:10px solid #a94442;
        }
    `],
    template: `
    <div class="panel panel-default">
        <div class="panel-heading">
            Add City<button class="ui button" style="float:right" (click)="closeClicked()">Close</button>
        </div>
        <div class="panel-body">
            <form [ngFormModel]="cityForm" (ngSubmit)="addCityClicked()">
                <div class="form-group row">
                    <label class="col-xs-5 form-control-label">City</label>
                    <div class="col-xs-7">
                        <input class="form-control" type="text" id="city" placeholder="city" [ngFormControl]="cityForm.controls['city']" required>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-xs-5 form-control-label">Country</label>
                    <div class="col-xs-7">
                        <input class="form-control" type="text" id="country" placeholder="country" [ngFormControl]="cityForm.controls['country']" required>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-xs-12">
                        <button class="ui button">Add</button>
                    </div>
                </div>
            </form>
        </div>
        <div class="panel-heading">
            Add Zip
        </div>
        <div class="panel-body">
            <form [ngFormModel]="zipForm" (ngSubmit)="addZipClicked()">
                <div class="form-group row">
                    <label class="col-xs-5 form-control-label">Zip</label>
                    <div class="col-xs-7">
                        <input class="form-control" type="text" id="zip" placeholder="00000" [ngFormControl]="zipForm.controls['zip']" size="5" maxlength="5" required>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-xs-12">
                        <button class="ui button">Add</button>
                    </div>
                </div>
            </form>
        </div>
        <div class="panel-heading">Remove Location</div>
        <div class="panel-body">        
            <div *ngFor="#location of weatherSvc.getSavedLocations();#i = index"> 
                <span *ngIf="location" style="float:left;margin:5px;padding:5px;border:1px solid #c0c0c0">
                {{ location?.name }}
                <label
                    class="btn btn-primary"
                    btnRadio="location" 
                    (click)="deleteClicked(i)">X</label>
                </span>
            </div>            
        </div>
    </div>
    `
}) 

export class SavedLocationsEditor {
    weatherSvc:WeatherSvc;
    city:Control;
    country:Control;
    cityForm:ControlGroup;
    zip:Control;
    zipForm:ControlGroup;
    @Output() close = new EventEmitter();

    constructor(weatherSvc:WeatherSvc, fb:FormBuilder) {
        this.weatherSvc = weatherSvc;
        this.city = new Control('', Validators.required);
        this.country = new Control('', Validators.required);
        this.cityForm = fb.group({
            'city': this.city,
            'country': this.country
        });
        this.zip = new Control('', Validators.compose([ Validators.required, Validators.minLength(5), Validators.maxLength(5)]));
        this.zipForm = fb.group({
            'zip': this.zip            
        });
    }
    
    addCityClicked(){        
        if (!this.cityForm.valid){
            return;
        }        
        var savedLocation:ISavedLocationData = 
            {
                cityName:this.city.value, 
                countryCode:this.country.value, 
                zip:''
            };
        this.weatherSvc.addSavedLocation(savedLocation);
        this.city.updateValue('');
        this.country.updateValue('');
    }
    
    addZipClicked(){
        if (!this.zipForm.valid){
            return;
        }       
        var zip:string = this.zip.value; 
        if (isNaN(Number(zip))){
            alert("Zip must be numeric.");
            return;
        }
        var savedLocation:ISavedLocationData = 
            {
                cityName:'', 
                countryCode:'', 
                zip:zip
            };
        this.weatherSvc.addSavedLocation(savedLocation);
        this.zip.updateValue('');
    }

    closeClicked(){
        this.close.emit(null);
    }
    
    deleteClicked(savedLocationNumber:number){
        if (this.weatherSvc.getSavedLocationCount() == 1){
            alert('Cannot delete the last location.')
            return;
        }
        this.weatherSvc.deleteSavedLocation(savedLocationNumber);        
    }
                   
}
