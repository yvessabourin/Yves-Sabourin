import {Component, Input} from 'angular2/core';
import {NgIf} from 'angular2/common';
import {IMainData} from '../interfaces/iMainData';

@Component({
    selector: 'main',
    directives: [NgIf],
    template: `
    <p>Pressure: {{model?.pressure}}, 
    Humidity {{model?.humidity}},
    Temp {{round(((model?.temp - 273.15)*9/5)+32)}},
    Temp Min/Max:  {{round(((model?.temp_min - 273.15)*9/5)+32)}}/{{round(((model?.temp_max - 273.15)*9/5)+32)}}
    </p>
    `
}) 

export class Main {
    @Input() model:IMainData;
    
    round(value:number){
        return Math.round(value);
    }
                   
}
