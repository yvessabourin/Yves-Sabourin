import {Http, Response} from 'angular2/http';
import {View, Component, NgZone} from 'angular2/core';
import {RouteConfig, Router, ROUTER_DIRECTIVES} from 'angular2/router';
import {FORM_PROVIDERS, NgIf} from 'angular2/common';
import {WeatherSvc} from '../services/weatherSvc';
import {Weather} from './weather';
import {Main} from './main';
import {Wind} from './wind';

@Component({
    selector: 'current', 
    providers: [...FORM_PROVIDERS],
    directives: [Weather, Main, Wind],
    template: `
    <div *ngIf="weatherSvc?.weatherData">    
        <weather [model]="weatherSvc?.weatherData"></weather>
        <main [model]="weatherSvc?.mainData"></main>
        <wind [model]="weatherSvc?.windData"></wind>
    </div>
  `
})

export class Current {
    weatherSvc: WeatherSvc;
    
    constructor(weatherSvc: WeatherSvc) {
        this.weatherSvc = weatherSvc;
    }            
}
