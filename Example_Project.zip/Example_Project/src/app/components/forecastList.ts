import {Component, Input} from 'angular2/core';
import {NgFor, NgIf, NgModel} from 'angular2/common';
import {IForecastListData} from '../interfaces/iForecastListData';
import {Weather} from './weather';
import {Main} from './main';
import {Wind} from './wind';

@Component({
    selector: 'forecastlist',
    directives: [NgFor, NgModel, Weather, Main, Wind],
    template: `
    <div *ngFor="#item of model; #i = index">
        <hr *ngIf="i > 0" />
        {{item.dt_txt}}
        <weather [model]="item.weather[0]"></weather>
        <main [model]="item.main"></main>
        <wind [model]="item.wind"></wind>
    </div>
    `
}) 

export class ForecastList {
    @Input() model:IForecastListData;
}
