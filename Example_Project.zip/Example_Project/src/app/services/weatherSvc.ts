import {Injectable} from 'angular2/core';
import {Http, Response, HTTP_PROVIDERS} from 'angular2/http';
import {ISavedLocationData} from '../interfaces/iSavedLocationData';
import {ICityData} from '../interfaces/iCityData';
import {IWeatherData} from '../interfaces/iWeatherData';
import {IMainData} from '../interfaces/iMainData';
import {IWindData} from '../interfaces/iWindData';
import {ICoOrdData} from '../interfaces/iCoOrdData';
import {IForecastListData} from '../interfaces/iForecastListData';
import {Observable} from 'rxjs/Observable';

const API_CODE = '482f496e96c1d252bf41556028327005';
//const API_CODE = 'b1b15e88fa797225412429c1c50c122a';
const OPEN_WEATHER_BASE_URL = 'http://api.openweathermap.org/data/2.5/';

@Injectable()
export class WeatherSvc {
    private http:Http;
    private savedLocations:Array<ISavedLocationData>;
    private savedLocation:ISavedLocationData;
    private cityData:ICityData;
    private weatherData:IWeatherData;
    private mainData:IMainData;
    private windData:IWindData;
    private coOrdData:ICoOrdData;
    private forecastListData:IForecastListData;
    
    public constructor(http:Http){
        this.http = http;
        this.savedLocations = new Array<ISavedLocationData>();
        this.loadSavedLocations();
        if (this.savedLocations.length < 1){
            this.addSavedLocation({zip:'90210'});            
        }
        this.savedLocation = this.savedLocations[0];
        
        this.refresh();
    }
       
    public getSavedLocations():Array<ISavedLocationData>{
        return this.savedLocations;
    }
    
    private getCurrentWeatherUrl():string{
        if (this.savedLocation.zip){
            return OPEN_WEATHER_BASE_URL + 
                'weather?zip=' + this.savedLocation.zip + ',us' + 
                '&appid=' + API_CODE;            
        }else{
            return OPEN_WEATHER_BASE_URL + 
                'weather?q=' + 
                this.savedLocation.cityName + ',' + this.savedLocation.countryCode + 
                '&appid=' + API_CODE;                        
        }
    }
    private get5DayWeatherUrl():string{
        if (this.savedLocation.zip){
            return OPEN_WEATHER_BASE_URL + 
                'forecast?zip=' + this.savedLocation.zip + ',us' + 
                '&appid=' + API_CODE;            
        }else{
            return OPEN_WEATHER_BASE_URL + 
                'forecast?q=' + 
                this.savedLocation.cityName + ',' + this.savedLocation.countryCode + 
                '&appid=' + API_CODE;                        
        }
    }
    
    private refresh(){
        Observable.forkJoin(
            this.http.get(this.getCurrentWeatherUrl()).retry(5).map((res: Response) => res.json()),
            this.http.get(this.get5DayWeatherUrl()).retry(5).map((res: Response) => res.json())
        ).subscribe(
            data => {
                var currentWeatherData = data[0];
                this.weatherData = currentWeatherData.weather[0];
                this.mainData = currentWeatherData.main;
                this.windData = currentWeatherData.wind;
                this.coOrdData = currentWeatherData.coord;    
                            
                var fiveDayWeatherData = data[1];
                this.cityData = fiveDayWeatherData.city;
                this.forecastListData = fiveDayWeatherData.list;
            }
        )      
    }    

    public savedLocationChanged(location:ISavedLocationData){
        this.savedLocation = location;
        this.refresh();
    } 
    
    public addSavedLocation(location:ISavedLocationData){
        if (location.zip){
            location.name = 'Zip Code: ' + location.zip;
        }else{
            location.name = location.cityName + ',' + location.countryCode;
        }
        this.savedLocations.push(location);
        this.saveSavedLocations();
    }

    public deleteSavedLocation(savedLocationNumber:number){
        this.savedLocations[savedLocationNumber] = undefined;
        this.saveSavedLocations();
    }

    private loadSavedLocations(){
        var savedLocationsLength:string = localStorage.getItem('savedLocationsLength');
        if (savedLocationsLength){
            var savedLocationsLengthNumber = parseInt(savedLocationsLength);
            for (var i=0;i<savedLocationsLengthNumber;i++){
                var data:String = localStorage.getItem('savedLocations' + i);
                if (data){
                    var dataElements : string[] = data.split("|");
                    var savedLocation:ISavedLocationData = 
                        {cityName:dataElements[0], 
                            countryCode:dataElements[1], 
                            zip:dataElements[2]};
                    this.addSavedLocation(savedLocation);
                }
            }
        }
    }

    private saveSavedLocations(){
        var savedLocationsLength = this.savedLocations.length;
        var savedLocationNumber:number = 0;
        for (var i=0;i<savedLocationsLength;i++){
            var savedLocation:ISavedLocationData = this.savedLocations[i];
            if (savedLocation){
                var data:string = "";
                if (savedLocation.cityName){
                    data += savedLocation.cityName;
                }
                data += "|";
                if (savedLocation.countryCode){
                    data += savedLocation.countryCode;
                }
                data += "|";
                if (savedLocation.zip){
                    data += savedLocation.zip;
                }
                localStorage.setItem("savedLocations" + savedLocationNumber, data);   
                savedLocationNumber++;             
            }
        }
        localStorage.setItem('savedLocationsLength', savedLocationNumber + "");
    }
    
    public getSavedLocationCount():number{
        var count:number = 0;
        for (var i=0;i<this.savedLocations.length;i++){
            var savedLocation:ISavedLocationData = this.savedLocations[i];
            if (savedLocation){
                count++;
            }
        }
        return count;
    }
}

