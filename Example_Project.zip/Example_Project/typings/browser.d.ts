/// <reference path="browser/ambient/angular-protractor/angular-protractor.d.ts" />
/// <reference path="browser/ambient/es6-shim/es6-shim.d.ts" />
/// <reference path="browser/ambient/hammerjs/hammerjs.d.ts" />
/// <reference path="browser/ambient/jasmine/jasmine.d.ts" />
/// <reference path="browser/ambient/node/node.d.ts" />
/// <reference path="browser/ambient/selenium-webdriver/selenium-webdriver.d.ts" />
/// <reference path="browser/ambient/zone/zone.d.ts" />
/// <reference path="browser/definitions/es6-promise/es6-promise.d.ts" />
