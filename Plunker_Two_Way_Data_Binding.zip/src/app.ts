import {Component} from 'angular2/core'

@Component({
  selector: 'my-app',
  providers: [],
  template: `
    First Name:<input [(ngModel)]="firstName"/>
    <br/>
    Last Name:<input [(ngModel)]="lastName"/>
    <br/>
    <br/>
    Value:{{firstName}} {{lastName}}
    <br/>
    <br/>
    <button (click)="setName()">set name</button>
  `,
  directives: []
})

export class App {
  firstName:string;
  lastName:string;
  
  constructor() {
    this.firstName = 'Peter';
    this.lastName = "Pan";
  }
  
  setName(){
    this.firstName = 'Fred';
    this.lastName = "Flintstone";
  }
}