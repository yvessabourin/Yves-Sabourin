import {View, Component} from 'angular2/core';
import {RouteConfig, Router, RouterLink, RouterOutlet, RouteParams, RouteData} from 'angular2/router';

@Component({
  selector: 'home',
  providers: [],
  template: `
    <div style="border:1px solid;padding:10px;">
      This is component 'Home' and it demonstrates router links.
      <br/>
      Administrator?:{{routeData.data['admin']}}
      <br/>
      Routing name {{router.hostComponent.name}}
      <br/>
      <br/>
      <a [routerLink]="['Other',{id:1}]">Other Component</a>
      <br/>
      <a [routerLink]="['../Other',{id:2},'Child1']">Child1 Subcomponent of Other</a>
      <br/>
      <a [routerLink]="['/Other',{id:3},'Child2']">Child2 Subcomponent of Other</a>
    </div>
  `,
  directives: [RouterLink]
})
export class Home {
  router:Router;
  routeData:RouteData;
  constructor(router:Router, routeData:RouteData) {
    this.router=router;
    this.routeData = routeData;
    this.routeData.data["admin"] = "y";
  }
}