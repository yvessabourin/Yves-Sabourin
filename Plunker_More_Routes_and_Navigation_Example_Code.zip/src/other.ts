import {View, Component} from 'angular2/core';
import {RouteConfig, Router, RouterLink, RouterOutlet, RouteParams, RouteData} from 'angular2/router';
import {Child1} from './child1';
import {Child2} from './child2';

@Component({
  selector: 'other',
  providers: [],
  template: `
    <div style="border:1px solid;padding:10px;">
      This is a component 'Other' that accepts a parameter and has subcomponents Child1 and Child2.
      <br/>
      It contains subcomponent Child1 by default.
      <br/>
      Administrator?:{{routeData.data['admin']}}
      <br/>
      Routing name {{router.hostComponent.name}}
      <br/>
      Param: {{id}}
      <br/>
      <br/>
      <router-outlet></router-outlet>
    </div>
  `,
  directives: [RouterLink, RouterOutlet]
})
@RouteConfig([
  { path: '/child1', component: Child1, as: 'Child1', useAsDefault: true },
  { path: '/child2', component: Child2, as: 'Child2' },
])
export class Other {
  router:Router;
  routeData:RouteData;
  
  constructor(router:Router, routeData:RouteData, params:RouteParams) {
    this.router = router;
    this.routeData = routeData;
    this.id = params.get('id');
  }
}