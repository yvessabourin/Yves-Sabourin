import {View, Component} from 'angular2/core';
import {RouteConfig, Router, RouterLink, RouterOutlet, RouteParams, RouteData} from 'angular2/router';

@Component({
  selector: 'child2',
  providers: [],
  template: `
    <div style="border:1px dotted">
      This is subcomponent Child2 and it demonstrates the 'Router.NavigateByUrl' method.
      <br/>
      Administrator?:{{routeData.data['admin']}}
      <br/>
      Routing name {{router.hostComponent.name}}
      <br/>
      <br/>
      <button (click)="home()">Component Home</button>
      <button (click)="child1Format1()">Subcomponent Child1 of Component Other</button>
    </div>
  `,
  directives: [RouterLink]
})
export class Child2 {
  router:Router;
  routeData:RouteData;
  
  constructor(router:Router, routeData:RouteData) {
    this.router=router;
    this.routeData = routeData;
  }
  home(){
    this.router.navigateByUrl('/');
  }
  child1Format1(){
    this.router.navigateByUrl('/other/child1?id=2');
  }
}