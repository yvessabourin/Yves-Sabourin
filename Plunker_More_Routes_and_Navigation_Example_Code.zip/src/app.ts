//our root app component
import {View, Component} from 'angular2/core';
import {RouteConfig, Router, RouterLink, RouterOutlet, RouteParams, RouteData} from 'angular2/router';
import {Home} from './home';
import {Other} from './other';

@Component({
  selector: 'my-app',
  template: `
    <main>
    <router-outlet></router-outlet>
    </main>
  `,
  directives: [RouterLink, RouterOutlet]
})
@RouteConfig([
  { path: '/', component: Home, as: 'Home' },
  { path: '/other/...', component: Other, as: 'Other' }
])

export class App {
  constructor(router:Router) {
    router.navigate(['./Home']););
  }
}