import {View, Component} from 'angular2/core';
import {RouteConfig, Router, RouterLink, RouterOutlet, RouteParams, RouteData} from 'angular2/router';

@Component({
  selector: 'child1',
  providers: [],
  template: `
    <div style="border:1px dotted">
      This is subcomponent Child1 and it demonstrates the 'Router.Navigate' method.
      <br/>
      Administrator?:{{routeData.data['admin']}}
      <br/>
      Routing name {{router.hostComponent.name}}
      <br/>
      <br/>
      <button (click)="home()">Component Home</button>
      <button (click)="child2Format1()">Subcomponent Child2 #1 of Component Other</button>
      <button (click)="child2Format2()">Subcomponent Child2 #2 of Component Other</button>
    </div>
  `,
  directives: [RouterLink]
})

export class Child1 {
  router:Router;
  routeData:RouteData;
  
  constructor(router:Router, routeData:RouteData) {
    this.router=router;
    this.routeData = routeData;
  }
  home(){
    this.router.navigate(['/Home']);
  }
  child2Format1(){
    this.router.navigate(['Child2']);
  }
  child2Format2(){
    this.router.navigate(['../Child2']);
  }
}