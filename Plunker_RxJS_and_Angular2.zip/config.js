System.config({
  //use typescript for compilation
  transpiler: 'typescript',
  //typescript compiler options
  typescriptOptions: {
    emitDecoratorMetadata: true
  },
  map:{
    '@reactivex/rxjs/dist/cjs/Rx' : 'Rx.js'
  }
});