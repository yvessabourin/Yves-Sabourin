import {bootstrap, Component, NgFor, View} from 'angular2/angular2';
import {HTTP_PROVIDERS, Http} from 'angular2/http';
import * as Rx from '@reactivex/rxjs/dist/cjs/Rx';

@Component({
  selector: 'app',
  providers: [HTTP_PROVIDERS]
})
@View({
  template: `
    <div>
      <h1>People</h1>
      <ul>
        <li *ng-for="#person of people">
          {{person.name}}
        </li>
      </ul>
    </div>
  `,
  directives: [NgFor]
})
export class App {
  people: Object[] = [];
  constructor(http:Http) {
    http.get('people.json')
      .flatMap(res => {
        //console.log(res._body);
        let array = JSON.parse(res._body);
        return Rx.Observable.fromArray(array)
      })
      .filter(res => {
        return res.name === "Jeff";
      })
      .subscribe(res => {
        this.people.push(res);
      });
  }
    
  toggleActiveState() {
    this.active = !this.active;
  }
  
}

bootstrap(App)
  .catch(err => console.error(err));
  