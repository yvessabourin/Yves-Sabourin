//our root app component
import {Component} from 'angular2/core'
import {Customer} from './customer';
import {Service} from './service';

@Component({
  selector: 'CustomerList',
  providers: [Service],
  template:
    `<div *ngFor="#customer of customers" class="customerList">
    <Customer class="green" [name]="[customer.name]" [address]="[customer.address]"></Customer>
    </div>`,
  directives: [Customer],
  styles: [`.customerList{border:1px solid green;margin:5px;padding:5px;}`]
})
export class CustomerList {
  constructor(service:Service) {
    this.customers = service.getCustomers();
  }
}