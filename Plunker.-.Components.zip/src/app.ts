//our root app component
import {Component} from 'angular2/core'
import {CustomerList} from './customerList';

@Component({
  selector: 'my-app',
  providers: [],
  template: `
    <div>
      <CustomerList></CustomerList>
    </div>
  `,
  directives: [CustomerList]
})
export class App {
  constructor() {
    this.name = 'Angular2'
  }
}