export class Service {
  constructor() {
    this.customers = [
      {name:"Mark",address:"Atlanta"},
      {name:"Peter",address:"Los Angeles"},
      {name:"Doug",address:"New York"}
    ]
  }
  
  getCustomers():any{
    return this.customers;
  }
}