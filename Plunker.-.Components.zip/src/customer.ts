//our root app component
import {Component,Input} from 'angular2/core'

@Component({
  selector: 'Customer',
  template: `<p>{{name}} : address {{address}}</p>`
})

export class Customer {
  @Input() name: string
  @Input() address: string
  constructor() {
  }
}